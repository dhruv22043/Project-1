# COMP2004 - Project-1

## Groceries App V1

This project entails building a simple yet functional grocery shopping app, utilizing most of the core programming concepts covered. As part of the task, students will create an interactive app where users can select grocery items from an inventory, view their cart contents, and check out.

Due Oct. 29th, 2024 @ 11:59 p.m.
