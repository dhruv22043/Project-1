import "./App.css";
import products from "./data/products";
import GroceriesAppContainer from "./components/GroceriesAppContainer";
import NavBar from "./components/NavBar";
import { useState } from "react";
import CartContainer from "./components/CartContainer";

function App() {
  const [cartItems, setCartItems] = useState([]); // Manage cart items state
  const username = "Dhruv";
  return (
    <>
      <div id="root">
        <NavBar username={username} cartItems={cartItems} />

        <GroceriesAppContainer />
      </div>
    </>
  );
}

export default App;
