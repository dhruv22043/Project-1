const QuantityCounter = ({ quantity, setQuantity }) => {
  const increaseQuantity = () => {
    setQuantity((prevQuantity) => prevQuantity + 1);
  };

  const decreaseQuantity = () => {
    if (quantity > 0) {
      setQuantity((prevQuantity) => prevQuantity - 1);
    }
  };

  return (
    <div className="QuantityBtn">
      <button onClick={decreaseQuantity}>-</button>
      {quantity}
      <button onClick={increaseQuantity}>+</button>
    </div>
  );
};

export default QuantityCounter;
